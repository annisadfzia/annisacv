<?php

namespace App\Controllers;

use App\Models\cvmodels;

class Home extends BaseController
{
    protected $annisacv;
    public function __construct()
    {
        $this->annisacv = new cvmodels;
    }

    public function index(): string
    {

        // About
        $abouts = new cvmodels();
        $about = $abouts->About();

        // Counts
        // $counts = new cvmodels();
        // $count = $counts->Counts();

        // Counts
        // $skills = new cvwebmodel();
        // $skill = $skills->Skills();

        $data = [
            // 'title_about' => 'About Me',
            'abouts' => $about,
            //'counts' => $count,
            // 'skill' => $skill
        ];
        return view('index', $data);
    }
}